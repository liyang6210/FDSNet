import torch
from models import CCNet
import os
import torchvision
from src import vit_base_patch16_224_in21k
from src import convnext_base


os.environ["TORCH_HOME"] = "./"
import torch.nn as nn
# model = CCNet(104)
# model = convnext_base(104)
# print(model)
# print('------------------------')



# for k,v in pth["meta"].items():
#     print(k)
# print('------------------------')
# for k,v in pth["optimizer"].items():
#     print(k)
# print('------------------------')
# # for k,v in model.state_dict().items():
# #     print(k)
# print(type(pth["meta"]))
# print('------------------------')
pth1 = torch.load('D:\data_set\weight_ported\checkpoints\SETR_Naive\iter_80000.pth')
for k,v in pth1['state_dict'].items():
    print(k)

print('------------------------')

model1 = vit_base_patch16_224_in21k(num_classes=104)
for k,v in model1.state_dict().items():
    print(k)



