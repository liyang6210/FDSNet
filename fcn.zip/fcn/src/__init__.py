from .ccnet import  ResNet, Seg_Model
from .SETR import SETR
from .vit_model import vit_base_patch16_224_in21k
from .ConvNeXt import convnext_base
from .ccnetPuP import  ResNet, Seg_ModelPuP
